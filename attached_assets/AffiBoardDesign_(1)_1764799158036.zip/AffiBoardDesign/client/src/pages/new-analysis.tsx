import { AppLayout } from "@/components/layout/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BrandButton } from "@/components/ui/brand-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, Sparkles, PlayCircle } from "lucide-react";
import { mockAnalyses } from "@/lib/mock-data";

export default function NewAnalysis() {
  return (
    <AppLayout title="Nova Análise">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[calc(100vh-140px)]">
        
        {/* Main Analysis Area */}
        <div className="lg:col-span-2 flex flex-col">
          <Card className="flex-1 bg-[#0F1F1D] border border-[#1BC1A1]/15 flex flex-col justify-center items-center p-8 md:p-16 text-center relative overflow-hidden shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-b from-[#005A52]/10 to-transparent pointer-events-none"></div>
            
            <div className="max-w-xl w-full relative z-10 space-y-8">
              <div className="mx-auto w-20 h-20 bg-gradient-brand rounded-3xl flex items-center justify-center shadow-[0_0_30px_rgba(27,193,161,0.3)] mb-6">
                <Sparkles className="h-10 w-10 text-white" />
              </div>
              
              <div className="space-y-2">
                <h2 className="text-3xl md:text-4xl font-bold text-white">Analise seu Conteúdo</h2>
                <p className="text-gray-400 text-lg">Cole o link do seu vídeo ou post para receber insights detalhados da nossa IA.</p>
              </div>

              <div className="space-y-4 pt-4">
                <div className="relative group">
                  <div className="absolute -inset-1 bg-gradient-to-r from-[#1BC1A1] to-[#005A52] rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                  <div className="relative flex items-center bg-[#0B1615] rounded-xl border border-[#1BC1A1]/30 p-2">
                    <div className="pl-4 text-gray-500">
                      <Search className="h-5 w-5" />
                    </div>
                    <Input 
                      className="border-0 bg-transparent text-white placeholder:text-gray-600 focus-visible:ring-0 focus-visible:ring-offset-0 text-lg py-6"
                      placeholder="Cole a URL aqui (TikTok, Instagram, YouTube)..."
                    />
                    <BrandButton className="h-12 px-8 rounded-lg shadow-lg">
                      Analisar Agora
                    </BrandButton>
                  </div>
                </div>
                <p className="text-xs text-gray-500">Suporta: TikTok, Reels, Shorts, Facebook Video</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Sidebar History */}
        <div className="lg:col-span-1 flex flex-col h-full">
          <Card className="h-full bg-[#0F1F1D] border border-[#1BC1A1]/15 flex flex-col">
            <CardHeader className="border-b border-[#1BC1A1]/10">
              <CardTitle className="text-white text-lg">Histórico Recente</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
              {mockAnalyses.map((item) => (
                <div key={item.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-[#1BC1A1]/5 border border-transparent hover:border-[#1BC1A1]/20 transition-all cursor-pointer group">
                  <div className="mt-1 h-8 w-8 rounded bg-[#1BC1A1]/10 text-[#1BC1A1] flex items-center justify-center flex-shrink-0">
                    <PlayCircle className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-white truncate group-hover:text-[#1BC1A1] transition-colors">{item.title}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-500">{item.platform}</span>
                      <span className="text-xs text-gray-600">•</span>
                      <span className="text-xs font-bold text-[#1BC1A1]">{item.score} pts</span>
                    </div>
                  </div>
                </div>
              ))}
              
              <div className="pt-4 text-center">
                <BrandButton variant="link" className="text-sm text-gray-400">
                  Ver histórico completo
                </BrandButton>
              </div>
            </CardContent>
          </Card>
        </div>

      </div>
    </AppLayout>
  );
}
