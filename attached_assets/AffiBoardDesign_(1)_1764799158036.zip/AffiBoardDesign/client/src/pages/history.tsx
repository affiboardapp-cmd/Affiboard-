import { AppLayout } from "@/components/layout/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { BrandButton } from "@/components/ui/brand-button";
import { mockAnalyses } from "@/lib/mock-data";
import { Search, Filter, Download } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export default function HistoryPage() {
  return (
    <AppLayout title="Minhas Análises">
      <Card className="bg-[#0F1F1D] border border-[#1BC1A1]/15 min-h-[600px]">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
          <CardTitle className="text-xl text-white">Todas as Análises</CardTitle>
          <div className="flex items-center gap-3">
            <BrandButton variant="outline" size="sm" className="border-[#1BC1A1]/30 text-gray-300 hover:text-[#1BC1A1]">
              <Download className="mr-2 h-4 w-4" /> Exportar CSV
            </BrandButton>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input 
                placeholder="Buscar por título..." 
                className="pl-10 bg-[#0B1615] border-[#1BC1A1]/20 text-white focus:border-[#1BC1A1] glow-focus"
              />
            </div>
            <div className="flex gap-3">
              <BrandButton variant="secondary" className="gap-2">
                <Filter className="h-4 w-4" /> Filtros
              </BrandButton>
              <BrandButton variant="primary">
                Buscar
              </BrandButton>
            </div>
          </div>

          {/* Table */}
          <div className="rounded-md border border-[#1BC1A1]/15 overflow-hidden">
            <Table>
              <TableHeader className="bg-[#005A52]/30">
                <TableRow className="border-b-[#1BC1A1]/15 hover:bg-transparent">
                  <TableHead className="text-[#1BC1A1]">Título</TableHead>
                  <TableHead className="text-[#1BC1A1]">Plataforma</TableHead>
                  <TableHead className="text-[#1BC1A1]">Score</TableHead>
                  <TableHead className="text-[#1BC1A1]">Data</TableHead>
                  <TableHead className="text-[#1BC1A1]">Status</TableHead>
                  <TableHead className="text-right text-[#1BC1A1]">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockAnalyses.map((analysis) => (
                  <TableRow key={analysis.id} className="border-b-[#1BC1A1]/10 hover:bg-[#1BC1A1]/5 transition-colors">
                    <TableCell className="font-medium text-gray-200">{analysis.title}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="border-[#1BC1A1]/30 text-gray-300 bg-[#1BC1A1]/5">
                        {analysis.platform}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className={`font-bold ${analysis.score > 90 ? 'text-[#1BC1A1]' : analysis.score > 70 ? 'text-yellow-500' : 'text-red-400'}`}>
                        {analysis.score}
                      </span>
                    </TableCell>
                    <TableCell className="text-gray-400">{analysis.date}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center gap-1.5 text-xs text-[#1BC1A1] font-medium bg-[#1BC1A1]/10 px-2 py-1 rounded-full">
                        <span className="h-1.5 w-1.5 rounded-full bg-[#1BC1A1]"></span>
                        {analysis.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <BrandButton variant="ghost" size="sm" className="h-8 text-[#1BC1A1] hover:text-white hover:bg-[#1BC1A1]">
                        Ver Detalhes
                      </BrandButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {/* Pagination */}
          <div className="flex items-center justify-end space-x-2 py-4">
            <BrandButton variant="outline" size="sm" disabled className="text-gray-500 border-gray-800">
              Anterior
            </BrandButton>
            <BrandButton variant="outline" size="sm" className="text-gray-300 border-[#1BC1A1]/30 hover:text-[#1BC1A1]">
              Próximo
            </BrandButton>
          </div>
        </CardContent>
      </Card>
    </AppLayout>
  );
}
