import { AppLayout } from "@/components/layout/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrandButton } from "@/components/ui/brand-button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Lock, CreditCard, Bell } from "lucide-react";

export default function SettingsPage() {
  return (
    <AppLayout title="Configurações">
      <Tabs defaultValue="profile" className="space-y-8">
        <TabsList className="bg-[#0F1F1D] border border-[#1BC1A1]/20 p-1 h-auto">
          <TabsTrigger value="profile" className="data-[state=active]:bg-[#1BC1A1] data-[state=active]:text-white text-gray-400 py-2">
            <User className="h-4 w-4 mr-2" /> Perfil
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-[#1BC1A1] data-[state=active]:text-white text-gray-400 py-2">
            <Lock className="h-4 w-4 mr-2" /> API & Segurança
          </TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-[#1BC1A1] data-[state=active]:text-white text-gray-400 py-2">
            <Bell className="h-4 w-4 mr-2" /> Notificações
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <div className="grid gap-6">
            <Card className="bg-[#0F1F1D] border border-[#1BC1A1]/15">
              <CardHeader>
                <CardTitle className="text-white">Informações Pessoais</CardTitle>
                <CardDescription className="text-gray-400">Atualize seus dados de conta</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4 mb-6">
                  <div className="h-20 w-20 rounded-full bg-[#1BC1A1]/20 flex items-center justify-center text-[#1BC1A1] text-2xl border-2 border-[#1BC1A1]">
                    UD
                  </div>
                  <div>
                    <BrandButton variant="secondary" size="sm">Alterar Foto</BrandButton>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-gray-300">Nome Completo</Label>
                    <Input defaultValue="Usuário Demo" className="bg-[#0B1615] border-[#1BC1A1]/20 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Email</Label>
                    <Input defaultValue="usuario@affiboard.com" className="bg-[#0B1615] border-[#1BC1A1]/20 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Empresa</Label>
                    <Input defaultValue="Minha Agência Ltda" className="bg-[#0B1615] border-[#1BC1A1]/20 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Cargo</Label>
                    <Input defaultValue="Marketing Manager" className="bg-[#0B1615] border-[#1BC1A1]/20 text-white" />
                  </div>
                </div>
                <div className="pt-4 flex justify-end">
                  <BrandButton>Salvar Alterações</BrandButton>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="security">
          <Card className="bg-[#0F1F1D] border border-[#1BC1A1]/15">
            <CardHeader>
              <CardTitle className="text-white">Chaves de API</CardTitle>
              <CardDescription className="text-gray-400">Gerencie o acesso programático à sua conta</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 rounded-lg bg-[#005A52]/20 border border-[#1BC1A1]/20 flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium text-white">Chave de Produção</p>
                  <p className="text-xs text-gray-500 font-mono">pk_live_51M...........................</p>
                </div>
                <BrandButton variant="outline" size="sm" className="border-[#1BC1A1]/30 text-[#1BC1A1]">Copiar</BrandButton>
              </div>
              
              <div className="space-y-4 pt-4 border-t border-[#1BC1A1]/10">
                <h3 className="text-white font-medium">Alterar Senha</h3>
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label className="text-gray-300">Senha Atual</Label>
                    <Input type="password" className="bg-[#0B1615] border-[#1BC1A1]/20 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Nova Senha</Label>
                    <Input type="password" className="bg-[#0B1615] border-[#1BC1A1]/20 text-white" />
                  </div>
                </div>
                <div className="pt-2">
                  <BrandButton variant="secondary">Atualizar Senha</BrandButton>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
           <Card className="bg-[#0F1F1D] border border-[#1BC1A1]/15">
            <CardHeader>
              <CardTitle className="text-white">Preferências de Notificação</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base text-white">Alertas de Análise</Label>
                  <p className="text-sm text-gray-400">Receba um email quando uma análise for concluída.</p>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-[#1BC1A1]" />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base text-white">Saldo Baixo</Label>
                  <p className="text-sm text-gray-400">Notificar quando meus créditos estiverem acabando.</p>
                </div>
                <Switch defaultChecked className="data-[state=checked]:bg-[#1BC1A1]" />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base text-white">Novidades do Produto</Label>
                  <p className="text-sm text-gray-400">Receba novidades sobre features e melhorias.</p>
                </div>
                <Switch className="data-[state=checked]:bg-[#1BC1A1]" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
}
