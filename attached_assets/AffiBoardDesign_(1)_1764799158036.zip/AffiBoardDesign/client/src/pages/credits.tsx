import { AppLayout } from "@/components/layout/layout";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { BrandButton } from "@/components/ui/brand-button";
import { plans, creditHistory } from "@/lib/mock-data";
import { Check, Zap } from "lucide-react";

export default function CreditsPage() {
  return (
    <AppLayout title="Gerenciar Créditos">
      <div className="space-y-10">
        
        {/* Current Balance */}
        <div className="bg-gradient-brand rounded-2xl p-8 shadow-brand relative overflow-hidden">
          <div className="absolute right-0 top-0 h-full w-1/2 bg-white/5 transform skew-x-12 pointer-events-none"></div>
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <p className="text-white/80 font-medium mb-1">Saldo Disponível</p>
              <h2 className="text-4xl md:text-5xl font-bold text-white">450 <span className="text-2xl font-normal opacity-70">créditos</span></h2>
            </div>
            <BrandButton className="bg-white text-[#005A52] hover:bg-gray-100 hover:text-[#005A52] shadow-lg border-0 font-bold text-lg px-8 py-6 h-auto">
              Recarregar Agora
            </BrandButton>
          </div>
        </div>

        {/* Plans */}
        <div>
          <h2 className="text-xl font-semibold text-white mb-6">Planos de Recarga</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <Card key={plan.name} className={`bg-[#0F1F1D] border ${plan.popular ? 'border-[#1BC1A1] shadow-brand' : 'border-[#1BC1A1]/15'} relative flex flex-col`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#1BC1A1] text-[#005A52] text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-lg">
                    Mais Popular
                  </div>
                )}
                <CardHeader className="text-center pb-4 pt-8">
                  <h3 className="text-lg font-medium text-gray-300">{plan.name}</h3>
                  <div className="flex items-baseline justify-center gap-1 mt-2">
                    <span className="text-4xl font-bold text-white">{plan.price}</span>
                  </div>
                  <p className="text-[#1BC1A1] font-medium mt-2">{plan.credits} Créditos</p>
                </CardHeader>
                <CardContent className="flex-1">
                  <ul className="space-y-3 mt-4">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3 text-sm text-gray-400">
                        <div className="h-5 w-5 rounded-full bg-[#1BC1A1]/10 flex items-center justify-center text-[#1BC1A1]">
                          <Check className="h-3 w-3" />
                        </div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="pt-4">
                  <BrandButton 
                    variant={plan.popular ? "primary" : "secondary"} 
                    className="w-full"
                  >
                    Escolher {plan.name}
                  </BrandButton>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>

        {/* History Table */}
        <div>
          <h2 className="text-xl font-semibold text-white mb-6">Histórico de Transações</h2>
          <Card className="bg-[#0F1F1D] border border-[#1BC1A1]/15">
            <CardContent className="p-0">
              <table className="w-full text-sm text-left">
                <thead className="bg-[#005A52]/20 text-gray-300 uppercase text-xs font-medium">
                  <tr>
                    <th className="px-6 py-4">Tipo</th>
                    <th className="px-6 py-4">Descrição</th>
                    <th className="px-6 py-4">Data</th>
                    <th className="px-6 py-4">Valor</th>
                    <th className="px-6 py-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1BC1A1]/10">
                  {creditHistory.map((item) => (
                    <tr key={item.id} className="hover:bg-[#1BC1A1]/5 text-gray-300">
                      <td className="px-6 py-4">
                        <span className={`flex items-center gap-2 ${item.type === 'Purchase' ? 'text-[#1BC1A1]' : 'text-gray-400'}`}>
                          {item.type === 'Purchase' ? <Zap className="h-4 w-4" /> : <div className="h-4 w-4" />}
                          {item.type}
                        </span>
                      </td>
                      <td className="px-6 py-4">{item.description || "Compra de Pacote"}</td>
                      <td className="px-6 py-4">{item.date}</td>
                      <td className={`px-6 py-4 font-medium ${item.amount > 0 ? 'text-[#1BC1A1]' : 'text-gray-400'}`}>
                        {item.amount > 0 ? '+' : ''}{item.amount}
                      </td>
                      <td className="px-6 py-4">
                        <span className="bg-green-900/30 text-green-400 px-2 py-1 rounded text-xs">
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
