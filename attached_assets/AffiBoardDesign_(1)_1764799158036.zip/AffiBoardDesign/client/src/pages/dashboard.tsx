import { AppLayout } from "@/components/layout/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BrandButton } from "@/components/ui/brand-button";
import { mockAnalyses } from "@/lib/mock-data";
import { Activity, TrendingUp, Zap, BarChart3, ArrowUpRight } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  return (
    <AppLayout title="Visão Geral">
      <div className="space-y-8">
        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard 
            title="Total de Análises" 
            value="1,284" 
            icon={Activity} 
            trend="+12% este mês"
          />
          <MetricCard 
            title="Confiança Média" 
            value="87%" 
            icon={Zap} 
            trend="+2.4% vs média"
          />
          <MetricCard 
            title="Créditos Restantes" 
            value="450" 
            icon={TrendingUp} 
            trend="Recarregue agora"
            action={true}
          />
          <MetricCard 
            title="ROI Estimado" 
            value="3.2x" 
            icon={BarChart3} 
            trend="Baseado em histórico"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">Últimas Análises</h2>
              <BrandButton variant="secondary" size="sm" asChild>
                <Link href="/history">Ver todas</Link>
              </BrandButton>
            </div>
            
            <div className="grid gap-4">
              {mockAnalyses.slice(0, 3).map((analysis) => (
                <div key={analysis.id} className="group bg-[#0F1F1D] border border-[#1BC1A1]/15 rounded-xl p-4 hover:border-[#1BC1A1]/40 transition-all shadow-card hover:shadow-brand/10 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                      analysis.platform === 'TikTok' ? 'bg-black/50' : 
                      analysis.platform === 'Instagram' ? 'bg-purple-900/20' : 
                      analysis.platform === 'YouTube' ? 'bg-red-900/20' : 'bg-blue-900/20'
                    }`}>
                      <span className="text-xs font-bold text-white/70">{analysis.platform.slice(0,2)}</span>
                    </div>
                    <div>
                      <h3 className="font-medium text-white group-hover:text-[#1BC1A1] transition-colors">{analysis.title}</h3>
                      <p className="text-sm text-gray-400">{analysis.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <div className="text-sm text-gray-400">Score</div>
                      <div className="text-lg font-bold text-[#1BC1A1]">{analysis.score}</div>
                    </div>
                    <Button variant="ghost" size="icon" className="text-gray-500 hover:text-white">
                      <ArrowUpRight className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions / Credits */}
          <div className="space-y-6">
            <h2 className="text-lg font-semibold text-white">Acesso Rápido</h2>
            <Card className="bg-gradient-to-br from-[#005A52] to-[#0F1F1D] border-[#1BC1A1]/30">
              <CardHeader>
                <CardTitle className="text-white">Nova Análise</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 mb-6 text-sm">
                  Descubra o potencial viral do seu próximo conteúdo em segundos.
                </p>
                <BrandButton className="w-full" asChild>
                  <Link href="/new-analysis">
                    <Plus className="mr-2 h-4 w-4" />
                    Analisar URL
                  </Link>
                </BrandButton>
              </CardContent>
            </Card>

            <div className="bg-[#0F1F1D] border border-[#1BC1A1]/15 rounded-xl p-6">
              <h3 className="text-white font-medium mb-4">Status do Sistema</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">API Latency</span>
                  <span className="text-[#1BC1A1]">24ms</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">AI Engine</span>
                  <span className="text-[#1BC1A1]">Online</span>
                </div>
                <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden mt-2">
                  <div className="h-full w-[98%] bg-[#1BC1A1]"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

function MetricCard({ title, value, icon: Icon, trend, action = false }: any) {
  return (
    <Card className="bg-[#0F1F1D] border border-[#1BC1A1]/15 shadow-card hover:shadow-brand/20 transition-all duration-300 group">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="p-2 bg-[#1BC1A1]/10 rounded-lg text-[#1BC1A1] group-hover:bg-[#1BC1A1] group-hover:text-white transition-colors">
            <Icon className="h-5 w-5" />
          </div>
          {action && (
            <Link href="/credits" className="text-xs font-bold text-[#1BC1A1] bg-[#1BC1A1]/10 px-2 py-1 rounded cursor-pointer hover:bg-[#1BC1A1] hover:text-white transition-colors">
              ADD +
            </Link>
          )}
        </div>
        <div className="space-y-1">
          <p className="text-sm text-gray-400 font-medium">{title}</p>
          <h3 className="text-2xl font-bold text-white">{value}</h3>
          <p className="text-xs text-gray-500 flex items-center gap-1">
            <span className={trend.includes('+') ? "text-[#1BC1A1]" : "text-gray-400"}>{trend}</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
