import { BrandButton } from "@/components/ui/brand-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useLocation } from "wouter";

export default function LoginPage() {
  const [_, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation("/");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#005A52] relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,#1BC1A1_0%,transparent_50%)] opacity-20"></div>
      <div className="absolute top-0 left-0 w-full h-full bg-[url('/noise.png')] opacity-5"></div>

      <div className="w-full max-w-md px-4 relative z-10">
        <div className="flex flex-col items-center mb-8">
          <div className="h-16 w-16 bg-gradient-brand rounded-2xl flex items-center justify-center shadow-brand mb-4">
             <img 
                src="/attached_assets/Screenshot_20251113-142527_1764798412883.png" 
                alt="Logo" 
                className="h-12 w-12 object-cover rounded-xl opacity-90 mix-blend-multiply"
              />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">AFFIBOARD</h1>
          <p className="text-[#1BC1A1] text-sm font-medium tracking-widest uppercase mt-2">Analytics Intelligence</p>
        </div>

        <Card className="bg-[#0F1F1D] border border-[#1BC1A1]/20 shadow-2xl backdrop-blur-sm">
          <CardHeader className="text-center pb-2">
            <h2 className="text-xl font-semibold text-white">Bem-vindo de volta</h2>
            <p className="text-gray-400 text-sm">Acesse seu painel de inteligência</p>
          </CardHeader>
          <CardContent className="pt-6">
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-300">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="seu@email.com" 
                  className="bg-[#0B1615] border-[#1BC1A1]/25 text-white focus:border-[#1BC1A1] focus:ring-1 focus:ring-[#1BC1A1] glow-focus transition-all"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-gray-300">Senha</Label>
                  <a href="#" className="text-xs text-[#1BC1A1] hover:underline">Esqueci minha senha</a>
                </div>
                <Input 
                  id="password" 
                  type="password" 
                  className="bg-[#0B1615] border-[#1BC1A1]/25 text-white focus:border-[#1BC1A1] focus:ring-1 focus:ring-[#1BC1A1] glow-focus transition-all"
                />
              </div>
              
              <BrandButton type="submit" className="w-full py-6 text-lg" variant="primary">
                Entrar no Sistema
              </BrandButton>
            </form>
          </CardContent>
        </Card>
        
        <p className="text-center text-gray-400 text-sm mt-8">
          Não tem uma conta? <a href="#" className="text-[#1BC1A1] font-medium hover:underline">Solicite acesso</a>
        </p>
      </div>
    </div>
  );
}
